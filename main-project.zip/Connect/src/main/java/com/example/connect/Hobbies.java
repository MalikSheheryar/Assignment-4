package com.example.connect;

public enum Hobbies {
    PAINTING,
    BAKING,
    BINGE_WATCHING,
    SKETCHING,
    KNITTING,
    PHOTOGRAPHY,
    WRITING,
    DANCE,
    COOKING,
    CHESS,
    PROGRAMMING,
    GUITAR,
    SPORTS,
    SEWING,
    GAMING,
    READING,
    WOOD_CRAFT,
    DIYS,
    SHOPPING,
    SINGING;
}
