package com.example.connect;

public enum Religion {
    ISLAM,
    CHRISTIANITY,
    HINDUISM,
    JUDAISM,
    ATHEISM,
    SIKHISM,
    BUDDHISM;
}
