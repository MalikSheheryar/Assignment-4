package com.example.connect;

public enum Gender {
    MALE,
    FEMALE;
}
